// gerenciador_biblioteca.cpp
// Um exemplo de aplicação/biblioteca em C++ que implementa um gerenciador de biblioteca
// Requisitos atendidos (resumo):
// - Abstração: classes: Book, User (abstract), Member, Librarian, Loan, Catalog, Library
// - Encapsulamento: membros privados, interfaces públicas controladas
// - Herança: User -> Member / Librarian
// - Polimorfismo estático: sobrecarga de funções e operadores
// - Polimorfismo dinâmico: métodos virtuais em User
// - Programação genérica: template Repository<T>
// - Regra dos 3 implementada na classe ResourceHolder (exemplo de gerenciamento manual)
// - Boas práticas: documentação, nomenclatura, RAII quando adequado, uso de std::unique_ptr

#include <algorithm>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <sstream>
#include <vector>

// -------------------------------------------------------------
// Pequena classe para demonstrar Regra dos Três (Rule of Three)
// Essa classe gerencia um buffer C-style para simular gerenciamento manual.
// Em aplicações modernas os containers std::string/std::vector devem ser preferidos.
// -------------------------------------------------------------
class ResourceHolder {
private:
    char *buffer_; // recurso gerenciado manualmente
    std::size_t size_;

public:
    // construtor
    ResourceHolder(const char *text = "") : buffer_(nullptr), size_(0) {
        if (text) {
            size_ = std::strlen(text) + 1;
            buffer_ = new char[size_];
            std::memcpy(buffer_, text, size_);
        }
    }

    // Destrutor (Rule of Three)
    ~ResourceHolder() {
        delete[] buffer_;
    }

    // Copy constructor (Rule of Three)
    ResourceHolder(const ResourceHolder &other) : buffer_(nullptr), size_(other.size_) {
        if (other.buffer_) {
            buffer_ = new char[size_];
            std::memcpy(buffer_, other.buffer_, size_);
        }
    }

    // Copy assignment operator (Rule of Three)
    ResourceHolder &operator=(const ResourceHolder &other) {
        if (this == &other) return *this;
        delete[] buffer_;
        buffer_ = nullptr;
        size_ = other.size_;
        if (other.buffer_) {
            buffer_ = new char[size_];
            std::memcpy(buffer_, other.buffer_, size_);
        }
        return *this;
    }

    // getters
    std::string str() const { return buffer_ ? std::string(buffer_) : std::string(); }
};

// -------------------------------------------------------------
// Classe Book - representa um livro físico/registro
// -------------------------------------------------------------
class Book {
private:
    std::string isbn_;
    std::string title_;
    std::string author_;
    int year_;
    bool available_;
    ResourceHolder coverNote_; // demonstra Rule of Three se necessário

public:
    Book() = default;
    Book(std::string isbn, std::string title, std::string author, int year, std::string coverNote = "")
        : isbn_(std::move(isbn)), title_(std::move(title)), author_(std::move(author)), year_(year), available_(true), coverNote_(coverNote) {}

    // Encapsulamento: getters / setters controlados
    const std::string &isbn() const { return isbn_; }
    const std::string &title() const { return title_; }
    const std::string &author() const { return author_; }
    int year() const { return year_; }
    bool available() const { return available_; }
    void setAvailable(bool v) { available_ = v; }

    // Exemplo de polimorfismo estático: sobrecarga de operadores
    bool operator==(const Book &other) const { return isbn_ == other.isbn_; }
    bool operator!=(const Book &other) const { return !(*this == other); }

    // Formatação para saída
    std::string toString() const {
        std::ostringstream oss;
        oss << "[" << isbn_ << "] " << title_ << " — " << author_ << " (" << year_ << ")"
            << (available_ ? " [disponível]" : " [emprestado]")
            << (coverNote_.str().empty() ? "" : " — nota: " + coverNote_.str());
        return oss.str();
    }

    // operador de saída
    friend std::ostream &operator<<(std::ostream &os, const Book &b) {
        os << b.toString();
        return os;
    }
};

// -------------------------------------------------------------
// Template Repository<T> - programação genérica para armazenar itens
// Fornece operações básicas: add, remove, find, list
// -------------------------------------------------------------
template <typename T>
class Repository {
private:
    std::vector<T> items_;

public:
    Repository() = default;
    explicit Repository(std::vector<T> items) : items_(std::move(items)) {}

    // adiciona item (sobrecarga: aceita rvalue e lvalue)
    void add(const T &item) { items_.push_back(item); }
    void add(T &&item) { items_.push_back(std::move(item)); }

    // remove por predicado
    template <typename Pred>
    bool remove_if(Pred predicate) {
        auto it = std::remove_if(items_.begin(), items_.end(), predicate);
        bool removed = it != items_.end();
        items_.erase(it, items_.end());
        return removed;
    }

    // encontra primeiro por predicado
    template <typename Pred>
    T *find_if(Pred predicate) {
        auto it = std::find_if(items_.begin(), items_.end(), predicate);
        return it == items_.end() ? nullptr : &(*it);
    }

    const std::vector<T> &all() const { return items_; }
    std::size_t size() const { return items_.size(); }
};

// -------------------------------------------------------------
// Classe Loan - representa um empréstimo
// -------------------------------------------------------------
class Loan {
private:
    std::string isbn_;
    int memberId_;
    std::time_t loanDate_;
    std::time_t dueDate_;

public:
    Loan(std::string isbn, int memberId, std::time_t loanDate, std::time_t dueDate)
        : isbn_(std::move(isbn)), memberId_(memberId), loanDate_(loanDate), dueDate_(dueDate) {}

    const std::string &isbn() const { return isbn_; }
    int memberId() const { return memberId_; }
    std::time_t loanDate() const { return loanDate_; }
    std::time_t dueDate() const { return dueDate_; }

    std::string toString() const {
        std::ostringstream oss;
        oss << "ISBN: " << isbn_ << " | Member: " << memberId_ << " | Due: " << std::asctime(std::localtime(&dueDate_));
        return oss.str();
    }
};

// -------------------------------------------------------------
// User (abstrato) — demonstra polimorfismo dinâmico
// -------------------------------------------------------------
class User {
protected:
    int id_;
    std::string name_;

public:
    User(int id, std::string name) : id_(id), name_(std::move(name)) {}
    virtual ~User() = default; // polimorfismo seguro

    int id() const { return id_; }
    const std::string &name() const { return name_; }

    // comportamento que pode variar entre usuários
    virtual std::string role() const = 0;                   // sobrescrito
    virtual bool canLoan() const = 0;                       // sobrescrito
    virtual int maxLoansAllowed() const = 0;                // sobrescrito

    virtual std::string info() const {
        std::ostringstream oss;
        oss << "[" << id_ << "] " << name_ << " (" << role() << ")";
        return oss.str();
    }
};

// -------------------------------------------------------------
// Member - usuário que pode pegar livros emprestados
// -------------------------------------------------------------
class Member : public User {
private:
    int activeLoans_;
    // exemplo de membro que gerencia memória dinamicamente (apenas para demonstrar Rule of Three via ResourceHolder no Book)

public:
    Member(int id, std::string name) : User(id, std::move(name)), activeLoans_(0) {}

    std::string role() const override { return "Member"; }
    bool canLoan() const override { return activeLoans_ < maxLoansAllowed(); }
    int maxLoansAllowed() const override { return 5; }

    void incrementLoans() { ++activeLoans_; }
    void decrementLoans() { if (activeLoans_>0) --activeLoans_; }
    int activeLoans() const { return activeLoans_; }
};

// -------------------------------------------------------------
// Librarian - usuário com permissões administrativas
// -------------------------------------------------------------
class Librarian : public User {
public:
    Librarian(int id, std::string name) : User(id, std::move(name)) {}

    std::string role() const override { return "Librarian"; }
    bool canLoan() const override { return true; }
    int maxLoansAllowed() const override { return 1000; }
};

// -------------------------------------------------------------
// Catalog - manipula coleção de livros (usa Repository<Book>)
// -------------------------------------------------------------
class Catalog {
private:
    Repository<Book> repo_;

public:
    Catalog() = default;

    // adiciona livro (sobrecarga: aceita parâmetros e objeto Book)
    void addBook(const Book &book) { repo_.add(book); }
    void addBook(Book &&book) { repo_.add(std::move(book)); }

    bool removeByISBN(const std::string &isbn) {
        return repo_.remove_if([&](const Book &b) { return b.isbn() == isbn; });
    }

    Book *findByISBN(const std::string &isbn) { return repo_.find_if([&](const Book &b) { return b.isbn() == isbn; }); }

    std::vector<Book> listAll() const { return repo_.all(); }
};

// -------------------------------------------------------------
// Library - orquestra usuários, catálogo e empréstimos
// -------------------------------------------------------------
class Library {
private:
    Catalog catalog_;
    Repository<Loan> loans_;
    std::vector<std::unique_ptr<User>> users_;

public:
    Library() = default;

    // Usuários
    void addUser(std::unique_ptr<User> user) {
        users_.push_back(std::move(user));
    }

    User *findUserById(int id) {
        for (auto &u : users_) if (u->id() == id) return u.get();
        return nullptr;
    }

    // Catálogo
    void addBook(const Book &book) { catalog_.addBook(book); }
    bool removeBook(const std::string &isbn) { return catalog_.removeByISBN(isbn); }

    // Empréstimo: simplificado — verifica disponibilidade e permissões
    bool loanBook(const std::string &isbn, int memberId, std::time_t days = 14) {
        Book *b = catalog_.findByISBN(isbn);
        User *u = findUserById(memberId);
        if (!b) throw std::runtime_error("Livro não encontrado");
        if (!u) throw std::runtime_error("Usuário não encontrado");
        if (!u->canLoan()) return false;
        Member *m = dynamic_cast<Member *>(u);
        if (m == nullptr) throw std::runtime_error("Somente membros podem pegar livros emprestados neste exemplo");
        if (!b->available()) return false;

        // cria empréstimo
        std::time_t now = std::time(nullptr);
        std::time_t due = now + days * 24 * 3600;
        loans_.add(Loan(b->isbn(), m->id(), now, due));
        b->setAvailable(false);
        m->incrementLoans();
        return true;
    }

    bool returnBook(const std::string &isbn, int memberId) {
        // remove empréstimo correspondente
        bool removed = loans_.remove_if([&](const Loan &L) {
            return L.isbn() == isbn && L.memberId() == memberId;
        });
        if (!removed) return false;
        Book *b = catalog_.findByISBN(isbn);
        User *u = findUserById(memberId);
        if (b) b->setAvailable(true);
        if (u) {
            Member *m = dynamic_cast<Member *>(u);
            if (m) m->decrementLoans();
        }
        return true;
    }

    std::vector<Book> listBooks() const { return catalog_.listAll(); }

    std::vector<Loan> listLoans() const { return loans_.all(); }
};

// -------------------------------------------------------------
// Exemplo de uso (main) — demonstra os conceitos implementados
// -------------------------------------------------------------
int main() {
    Library lib;

    // adiciona usuários (polimorfismo dinâmico via ponteiros)
    lib.addUser(std::make_unique<Member>(1, "Ana"));
    lib.addUser(std::make_unique<Member>(2, "Carlos"));
    lib.addUser(std::make_unique<Librarian>(99, "Sra. Silva"));

    // adiciona livros
    lib.addBook(Book("978-0131103627", "The C Programming Language", "Kernighan & Ritchie", 1978, "Classic"));
    lib.addBook(Book("978-0201633610", "Design Patterns", "Gamma et al.", 1994));
    lib.addBook(Book("978-0262033848", "Introduction to Algorithms", "Cormen et al.", 2009));

    std::cout << "=== Livros no catálogo ===\n";
    for (const auto &b : lib.listBooks()) std::cout << b << "\n";

    std::cout << "\nTentando emprestar 'Design Patterns' para o membro 1...\n";
    try {
        bool ok = lib.loanBook("978-0201633610", 1, 7);
        std::cout << (ok ? "Emprestado com sucesso" : "Não foi possível emprestar") << "\n";
    } catch (const std::exception &ex) {
        std::cerr << "Erro: " << ex.what() << "\n";
    }

    std::cout << "\nEstado dos livros após empréstimo:\n";
    for (const auto &b : lib.listBooks()) std::cout << b << "\n";

    std::cout << "\nListando empréstimos:\n";
    for (const auto &l : lib.listLoans()) std::cout << l.toString();

    std::cout << "\nDevolvendo livro...\n";
    if (lib.returnBook("978-0201633610", 1)) std::cout << "Devolvido com sucesso\n";

    std::cout << "\nEstado final dos livros:\n";
    for (const auto &b : lib.listBooks()) std::cout << b << "\n";

    return 0;
}
